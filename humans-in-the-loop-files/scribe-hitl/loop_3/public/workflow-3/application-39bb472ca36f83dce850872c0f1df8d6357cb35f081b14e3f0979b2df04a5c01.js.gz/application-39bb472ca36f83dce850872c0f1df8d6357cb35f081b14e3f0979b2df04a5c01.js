import 'react-app-polyfill/ie11'
import 'react-app-polyfill/stable'

import './lib/jquery.extensions.js'
import './lib/marked.min.js'
import './lib/moment.min.js'
import './lib/proto.js'
import './lib/modernizr-custom.js'
import './components/app-router.jsx'
;
